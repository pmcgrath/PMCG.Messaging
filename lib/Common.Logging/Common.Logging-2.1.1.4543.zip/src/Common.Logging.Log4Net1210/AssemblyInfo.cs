using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework log4net 1.2.10 Adapter")]
[assembly: SecurityTransparent]