using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework Enterprise Library 4.1 Adapter")]
[assembly: SecurityTransparent]