using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework log4net 1.2.9 Adapter")]
[assembly: SecurityTransparent]