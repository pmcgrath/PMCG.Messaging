using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework Enterprise Library 3.1 Adapter")]
[assembly: SecurityTransparent]