using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework NLog 1.0.0.505 Adapter")]
[assembly: SecurityTransparent]