﻿using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework log4net 1.2.11 Adapter")]
[assembly: SecurityTransparent]