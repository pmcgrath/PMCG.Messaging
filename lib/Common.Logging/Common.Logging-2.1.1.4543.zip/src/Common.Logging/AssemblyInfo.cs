using System.Reflection;
using System.Security;

[assembly: AssemblyProduct("Common Logging Framework")]
[assembly: SecurityTransparent]