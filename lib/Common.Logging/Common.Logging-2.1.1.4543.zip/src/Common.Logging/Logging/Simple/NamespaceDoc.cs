#region License

/*
 * Copyright 2002-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#endregion

namespace Common.Logging.Simple
{
    /// <summary>
    /// <para>This namespace contains out-of-the-box adapters to intrinsic systems, namely
    /// <see cref="ConsoleOutLoggerFactoryAdapter"/>, <see cref="TraceLoggerFactoryAdapter"/> and the 
    /// all output suppressing <see cref="NoOpLoggerFactoryAdapter"/>.</para>
    /// <para>For unit testing, you may also want to have a look at <see cref="CapturingLoggerFactoryAdapter"/> 
    /// that allows to easily inspect logged messages.</para>
    /// <para>To route messages logged through the <see cref="System.Diagnostics.Trace"/> infrastructure back into
    /// Common.Logging, you can use <see cref="CommonLoggingTraceListener"/></para>
    /// </summary>
    [CoverageExclude]
    internal static class NamespaceDoc
    {
        // serves as namespace summary for NDoc3 (http://ndoc3.sourceforge.net)
    }
}