﻿using System.Reflection;

[assembly: AssemblyTitle("Spring")]
